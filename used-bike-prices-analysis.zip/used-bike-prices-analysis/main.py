import pandas as pd
import numpy as np
import os
import sys
import matplotlib.pyplot as plt
from pathlib import Path

# Add src directory to Python path
current_dir = Path(__file__).parent
src_path = current_dir / 'src'
sys.path.insert(0, str(src_path))

print("="*70)
print("🚀 USED BIKE PRICES ANALYSIS - STARTING")
print("="*70)

# Check if src modules exist
required_modules = [
    'data_preprocessing.py',
    'feature_engineering.py', 
    'visualization.py',
    'model_training.py'
]

missing_modules = []
for module in required_modules:
    if not os.path.exists(f'src/{module}'):
        missing_modules.append(module)

if missing_modules:
    print(f"❌ Missing modules in src/: {missing_modules}")
    print("Please make sure all source files are present.")
    sys.exit(1)

# Import modules
try:
    from data_preprocessing import DataPreprocessor
    from feature_engineering import FeatureEngineer
    from visualization import DataVisualizer
    from model_training import ModelTrainer
    print("✅ All modules imported successfully!")
except Exception as e:
    print(f"❌ Error importing modules: {e}")
    sys.exit(1)

def find_dataset():
    """Find the dataset file in common locations"""
    possible_paths = [
        'data/bikes.csv',
        'bikes.csv',
        'data/used_bikes.csv',
        'data/dataset.csv',
        'dataset.csv'
    ]
    
    for path in possible_paths:
        if os.path.exists(path):
            print(f"📁 Dataset found: {path}")
            return path
    
    print("❌ Dataset not found!")
    print("Please make sure your dataset is in one of these locations:")
    for path in possible_paths:
        print(f"  - {path}")
    return None

def run_data_preprocessing(df):
    """Run data preprocessing"""
    print("\n" + "="*70)
    print("🔧 STEP 1: DATA PREPROCESSING")
    print("="*70)
    
    preprocessor = DataPreprocessor()
    df_processed = preprocessor.preprocess_data(df)
    
    print(f"\n✅ Preprocessing complete!")
    print(f"   Original shape: {df.shape}")
    print(f"   Processed shape: {df_processed.shape}")
    print(f"   Columns: {list(df_processed.columns)}")
    
    return df_processed

def run_feature_engineering(df):
    """Run feature engineering"""
    print("\n" + "="*70)
    print("⚙️  STEP 2: FEATURE ENGINEERING")
    print("="*70)
    
    engineer = FeatureEngineer(current_year=2024)
    df_engineered = engineer.engineer_all_features(df)
    
    print(f"\n✅ Feature engineering complete!")
    print(f"   Original features: {len(df.columns)}")
    print(f"   Engineered features: {len(df_engineered.columns)}")
    
    # Show new features
    new_features = set(df_engineered.columns) - set(df.columns)
    if new_features:
        print(f"   New features created: {len(new_features)}")
        print("   Sample new features:", list(new_features)[:5])
    
    return df_engineered

def run_eda(df):
    """Run exploratory data analysis"""
    print("\n" + "="*70)
    print("📊 STEP 3: EXPLORATORY DATA ANALYSIS")
    print("="*70)
    
    visualizer = DataVisualizer(output_dir='reports/visualizations')
    
    # Create basic visualizations
    print("\nCreating visualizations...")
    
    # 1. Price distribution
    if 'price' in df.columns:
        print("  1. Plotting price distribution...")
        plt.figure(figsize=(12, 5))
        plt.subplot(1, 2, 1)
        plt.hist(df['price'], bins=50, edgecolor='black', alpha=0.7)
        plt.title('Price Distribution')
        plt.xlabel('Price (INR)')
        plt.ylabel('Frequency')
        
        plt.subplot(1, 2, 2)
        plt.hist(np.log1p(df['price']), bins=50, edgecolor='black', alpha=0.7)
        plt.title('Log-Transformed Price Distribution')
        plt.xlabel('log(Price + 1)')
        plt.ylabel('Frequency')
        plt.tight_layout()
        plt.savefig('reports/visualizations/price_distribution.png', dpi=300)
        plt.show()
    
    # 2. Correlation matrix
    numerical_cols = df.select_dtypes(include=[np.number]).columns
    if len(numerical_cols) > 1:
        print("  2. Creating correlation matrix...")
        corr_matrix = df[numerical_cols].corr()
        
        plt.figure(figsize=(10, 8))
        plt.imshow(corr_matrix, cmap='coolwarm', aspect='auto')
        plt.colorbar(label='Correlation')
        plt.title('Correlation Matrix')
        plt.xticks(range(len(numerical_cols)), numerical_cols, rotation=45, ha='right')
        plt.yticks(range(len(numerical_cols)), numerical_cols)
        
        # Add correlation values
        for i in range(len(numerical_cols)):
            for j in range(len(numerical_cols)):
                plt.text(j, i, f'{corr_matrix.iloc[i, j]:.2f}', 
                        ha='center', va='center', color='white' if abs(corr_matrix.iloc[i, j]) > 0.5 else 'black')
        
        plt.tight_layout()
        plt.savefig('reports/visualizations/correlation_matrix.png', dpi=300)
        plt.show()
    
    # 3. Key relationships
    print("  3. Analyzing key relationships...")
    
    relationships_to_plot = [
        ('model_year', 'price'),
        ('kms_driven', 'price'),
        ('power', 'price')
    ]
    
    for x_col, y_col in relationships_to_plot:
        if x_col in df.columns and y_col in df.columns:
            plt.figure(figsize=(8, 6))
            plt.scatter(df[x_col], df[y_col], alpha=0.5, s=20)
            plt.title(f'{y_col} vs {x_col}')
            plt.xlabel(x_col)
            plt.ylabel(y_col)
            
            # Add trend line
            try:
                z = np.polyfit(df[x_col].dropna(), df[y_col].dropna(), 1)
                p = np.poly1d(z)
                plt.plot(df[x_col].sort_values(), p(df[x_col].sort_values()), "r--", alpha=0.8)
            except:
                pass
            
            plt.tight_layout()
            plt.savefig(f'reports/visualizations/{y_col}_vs_{x_col}.png', dpi=300)
            plt.show()
    
    print("\n✅ EDA complete! Check 'reports/visualizations/' for plots.")
    return visualizer

def run_model_training(df):
    """Run model training and evaluation"""
    print("\n" + "="*70)
    print("🤖 STEP 4: MODEL TRAINING")
    print("="*70)
    
    if 'price' not in df.columns:
        print("❌ 'price' column not found. Cannot train models.")
        return None
    
    # Prepare data
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
    
    # Select numerical features only for simplicity
    X = df.select_dtypes(include=[np.number]).drop(columns=['price'], errors='ignore')
    y = df['price']
    
    if X.shape[1] == 0:
        print("❌ No numerical features found for training.")
        return None
    
    print(f"   Features: {X.shape[1]}")
    print(f"   Samples: {X.shape[0]}")
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    print(f"   Training samples: {X_train.shape[0]}")
    print(f"   Testing samples: {X_test.shape[0]}")
    
    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Train models
    models = {}
    results = []
    
    # Linear Regression
    print("\n  1. Training Linear Regression...")
    from sklearn.linear_model import LinearRegression
    lr = LinearRegression()
    lr.fit(X_train_scaled, y_train)
    y_pred_lr = lr.predict(X_test_scaled)
    
    models['Linear Regression'] = lr
    results.append({
        'Model': 'Linear Regression',
        'R²': r2_score(y_test, y_pred_lr),
        'RMSE': np.sqrt(mean_squared_error(y_test, y_pred_lr)),
        'MAE': mean_absolute_error(y_test, y_pred_lr)
    })
    
    # Random Forest
    print("  2. Training Random Forest...")
    from sklearn.ensemble import RandomForestRegressor
    rf = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
    rf.fit(X_train_scaled, y_train)
    y_pred_rf = rf.predict(X_test_scaled)
    
    models['Random Forest'] = rf
    results.append({
        'Model': 'Random Forest',
        'R²': r2_score(y_test, y_pred_rf),
        'RMSE': np.sqrt(mean_squared_error(y_test, y_pred_rf)),
        'MAE': mean_absolute_error(y_test, y_pred_rf)
    })
    
    # Display results
    results_df = pd.DataFrame(results)
    print("\n" + "-"*50)
    print("MODEL PERFORMANCE:")
    print("-"*50)
    print(results_df.to_string(index=False))
    
    # Plot actual vs predicted
    print("\n  3. Creating prediction plots...")
    
    fig, axes = plt.subplots(1, 2, figsize=(15, 6))
    
    # Linear Regression predictions
    axes[0].scatter(y_test, y_pred_lr, alpha=0.5)
    axes[0].plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
    axes[0].set_xlabel('Actual Price')
    axes[0].set_ylabel('Predicted Price')
    axes[0].set_title('Linear Regression: Actual vs Predicted')
    axes[0].grid(True, alpha=0.3)
    
    # Random Forest predictions
    axes[1].scatter(y_test, y_pred_rf, alpha=0.5)
    axes[1].plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
    axes[1].set_xlabel('Actual Price')
    axes[1].set_ylabel('Predicted Price')
    axes[1].set_title('Random Forest: Actual vs Predicted')
    axes[1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('reports/visualizations/predictions_comparison.png', dpi=300)
    plt.show()
    
    # Feature importance for Random Forest
    print("  4. Analyzing feature importance...")
    
    if hasattr(rf, 'feature_importances_'):
        feature_importance = pd.DataFrame({
            'Feature': X.columns,
            'Importance': rf.feature_importances_
        }).sort_values('Importance', ascending=False).head(10)
        
        plt.figure(figsize=(10, 6))
        plt.barh(feature_importance['Feature'], feature_importance['Importance'])
        plt.xlabel('Importance')
        plt.title('Top 10 Feature Importances (Random Forest)')
        plt.gca().invert_yaxis()
        plt.tight_layout()
        plt.savefig('reports/visualizations/feature_importance.png', dpi=300)
        plt.show()
        
        print("\nTop 5 Features:")
        for idx, row in feature_importance.head().iterrows():
            print(f"  {row['Feature']}: {row['Importance']:.4f}")
    
    # Save the best model
    best_model_idx = results_df['R²'].idxmax()
    best_model_name = results_df.loc[best_model_idx, 'Model']
    best_model = models[best_model_name]
    
    import joblib
    os.makedirs('models', exist_ok=True)
    joblib.dump(best_model, 'models/best_model.pkl')
    joblib.dump(scaler, 'models/scaler.pkl')
    
    print(f"\n✅ Model training complete!")
    print(f"   Best model: {best_model_name}")
    print(f"   Best R² score: {results_df.loc[best_model_idx, 'R²']:.4f}")
    print(f"   Models saved to: models/")
    
    return results_df

def main():
    """Main execution function"""
    
    # Step 0: Check project structure
    print("📁 Checking project structure...")
    
    # Ensure reports directory exists
    os.makedirs('reports/visualizations', exist_ok=True)
    os.makedirs('models', exist_ok=True)
    print("✅ Directories ready")
    
    # Step 1: Find and load dataset
    print("\n📊 Loading dataset...")
    dataset_path = find_dataset()
    
    if not dataset_path:
        return
    
    try:
        df = pd.read_csv(dataset_path)
        print(f"✅ Dataset loaded: {df.shape[0]} rows, {df.shape[1]} columns")
        print(f"   Columns: {list(df.columns)}")
        
        # Show sample
        print("\n📋 Sample data:")
        print(df.head())
        
    except Exception as e:
        print(f"❌ Error loading dataset: {e}")
        return
    
    # Step 2: Run preprocessing
    df_processed = run_data_preprocessing(df)
    
    # Step 3: Run feature engineering
    df_engineered = run_feature_engineering(df_processed)
    
    # Step 4: Run EDA
    run_eda(df_engineered)
    
    # Step 5: Run model training
    results = run_model_training(df_engineered)
    
    # Final summary
    print("\n" + "="*70)
    print("🎉 ANALYSIS COMPLETE!")
    print("="*70)
    
    print("\n📁 Generated Files:")
    print("  - reports/visualizations/ - All analysis plots")
    print("  - models/ - Trained machine learning models")
    
    print("\n📊 Summary Statistics:")
    print(f"  - Total records analyzed: {len(df_engineered)}")
    print(f"  - Total features: {len(df_engineered.columns)}")
    
    if results is not None and not results.empty:
        best_model = results.loc[results['R²'].idxmax()]
        print(f"  - Best model: {best_model['Model']}")
        print(f"  - Best R² score: {best_model['R²']:.4f}")
        print(f"  - Best RMSE: ₹{best_model['RMSE']:,.2f}")
    
    print("\n" + "="*70)
    print("Next steps:")
    print("  1. Check 'reports/visualizations/' for analysis plots")
    print("  2. Use notebooks/ for interactive analysis")
    print("  3. Check models/ for trained ML models")
    print("="*70)

if __name__ == "__main__":
    main()
"""
Data preprocessing module for Used Bike Prices project
"""

import pandas as pd
import numpy as np
import re
from typing import Tuple, Dict, List

class DataPreprocessor:
    """Class for preprocessing bike price data"""
    
    def __init__(self):
        self.brand_mapping = {
            'Ideal': 'Jawa',
            'yamaha': 'Yamaha',
            'Royal': 'Royal Enfield'
        }
        
    def load_data(self, filepath: str) -> pd.DataFrame:
        """Load data from CSV file"""
        try:
            df = pd.read_csv(filepath)
            print(f"Data loaded successfully from {filepath}")
            print(f"Shape: {df.shape}")
            return df
        except FileNotFoundError:
            print(f"File not found: {filepath}")
            return None
    
    def clean_column_names(self, df: pd.DataFrame) -> pd.DataFrame:
        """Clean column names"""
        df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')
        return df
    
    def handle_missing_values(self, df: pd.DataFrame) -> pd.DataFrame:
        """Handle missing values in the dataset"""
        print("\nHandling missing values...")
        
        # Check for missing values
        missing_values = df.isnull().sum()
        print("Missing values per column:")
        print(missing_values[missing_values > 0])
        
        # Fill missing values based on column type
        for column in df.columns:
            if df[column].isnull().sum() > 0:
                if df[column].dtype == 'object':
                    # For categorical, fill with mode
                    mode_value = df[column].mode()[0] if not df[column].mode().empty else 'Unknown'
                    df[column].fillna(mode_value, inplace=True)
                    print(f"  {column}: Filled {df[column].isnull().sum()} missing values with mode: {mode_value}")
                else:
                    # For numerical, fill with median
                    median_value = df[column].median()
                    df[column].fillna(median_value, inplace=True)
                    print(f"  {column}: Filled {df[column].isnull().sum()} missing values with median: {median_value}")
        
        return df
    
    def extract_cc_from_model(self, model_names: pd.Series) -> pd.Series:
        """Extract engine capacity from model names"""
        cc_values = []
        
        for model in model_names:
            if pd.isnull(model):
                cc_values.append(150)  # Default value
                continue
                
            model_str = str(model).lower()
            cc = 150  # Default value
            
            # Try to extract CC using regex patterns
            patterns = [
                r'(\d+)\s*cc',  # Matches "220cc" or "220 cc"
                r'(\d+)\s*ccs?',
                r'(\d+)\s*cubic',
                r'\b(\d{3})\b(?=.*cc)'  # Matches 3-digit numbers near "cc"
            ]
            
            for pattern in patterns:
                match = re.search(pattern, model_str)
                if match:
                    try:
                        cc = int(match.group(1))
                        break
                    except ValueError:
                        continue
            
            # If no pattern matched, check for common CC values in text
            if cc == 150:
                common_ccs = {
                    '1000': 1000, '950': 950, '900': 900, '883': 883, '800': 800,
                    '765': 765, '750': 750, '650': 650, '600': 600, '500': 500,
                    '400': 400, '390': 390, '350': 350, '330': 330, '310': 310,
                    '300': 300, '295': 295, '250': 250, '220': 220, '200': 200,
                    '180': 180, '160': 160, '150': 150, '135': 135, '125': 125,
                    '110': 110, '100': 100
                }
                
                for key, value in common_ccs.items():
                    if key in model_str:
                        cc = value
                        break
            
            cc_values.append(cc)
        
        return pd.Series(cc_values, index=model_names.index)
    
    def extract_brand_from_model(self, model_names: pd.Series) -> pd.Series:
        """Extract brand name from model names"""
        brands = []
        
        for model in model_names:
            if pd.isnull(model):
                brands.append('Unknown')
                continue
                
            # Split and get first word as brand
            first_word = str(model).split()[0] if str(model).split() else 'Unknown'
            brands.append(first_word)
        
        return pd.Series(brands, index=model_names.index)
    
    def clean_power_column(self, power_series: pd.Series) -> pd.Series:
        """Clean and convert power column to numeric values"""
        cleaned_power = []
        
        for power in power_series:
            if pd.isnull(power):
                cleaned_power.append(np.nan)
                continue
                
            power_str = str(power).lower().strip()
            
            # Remove units and convert to float
            # Remove bhp, hp, kw, ps, @, and other text
            power_str = re.sub(r'[a-zA-Z@&\(\)]', '', power_str)
            power_str = re.sub(r'[^\d.]', '', power_str)
            
            try:
                if power_str:
                    cleaned_power.append(float(power_str))
                else:
                    cleaned_power.append(np.nan)
            except ValueError:
                cleaned_power.append(np.nan)
        
        return pd.Series(cleaned_power, index=power_series.index)
    
    def clean_kms_driven(self, kms_series: pd.Series) -> pd.Series:
        """Clean kilometers driven column"""
        cleaned_kms = []
        
        for kms in kms_series:
            if pd.isnull(kms):
                cleaned_kms.append(np.nan)
                continue
                
            kms_str = str(kms).lower()
            
            # Extract numeric part
            match = re.search(r'(\d+)', kms_str)
            if match:
                try:
                    cleaned_kms.append(int(match.group(1)))
                except ValueError:
                    cleaned_kms.append(np.nan)
            else:
                cleaned_kms.append(np.nan)
        
        return pd.Series(cleaned_kms, index=kms_series.index)
    
    def clean_mileage(self, mileage_series: pd.Series) -> pd.Series:
        """Clean mileage column"""
        cleaned_mileage = []
        
        for mileage in mileage_series:
            if pd.isnull(mileage):
                cleaned_mileage.append(np.nan)
                continue
                
            mileage_str = str(mileage).lower()
            
            # Remove non-numeric characters except decimal point
            mileage_str = re.sub(r'[^\d.]', '', mileage_str)
            
            try:
                if mileage_str:
                    cleaned_mileage.append(float(mileage_str))
                else:
                    cleaned_mileage.append(np.nan)
            except ValueError:
                cleaned_mileage.append(np.nan)
        
        return pd.Series(cleaned_mileage, index=mileage_series.index)
    
    def preprocess_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Main preprocessing pipeline"""
        print("Starting data preprocessing...")
        
        # Clean column names
        df = self.clean_column_names(df)
        
        # Extract CC from model name
        if 'model_name' in df.columns:
            df['cc'] = self.extract_cc_from_model(df['model_name'])
            print("Extracted CC from model names")
        
        # Extract brand from model name
        if 'model_name' in df.columns:
            df['brand'] = self.extract_brand_from_model(df['model_name'])
            print("Extracted brand from model names")
            
            # Clean brand names
            df['brand'] = df['brand'].replace(self.brand_mapping)
            print("Cleaned brand names")
        
        # Clean other columns
        if 'power' in df.columns:
            df['power'] = self.clean_power_column(df['power'])
            print("Cleaned power column")
        
        if 'kms_driven' in df.columns:
            df['kms_driven'] = self.clean_kms_driven(df['kms_driven'])
            print("Cleaned kms_driven column")
        
        if 'mileage' in df.columns:
            df['mileage'] = self.clean_mileage(df['mileage'])
            print("Cleaned mileage column")
        
        # Handle missing values
        df = self.handle_missing_values(df)
        
        # Calculate bike age
        if 'model_year' in df.columns:
            current_year = pd.Timestamp.now().year
            df['bike_age'] = current_year - df['model_year']
            print(f"Calculated bike age (current year: {current_year})")
        
        print(f"\nPreprocessing completed. Final shape: {df.shape}")
        return df
    
    def get_preprocessing_summary(self, df: pd.DataFrame) -> Dict:
        """Get summary of preprocessing steps"""
        summary = {
            'original_shape': 'N/A',  # Would need original df
            'final_shape': df.shape,
            'columns': list(df.columns),
            'dtypes': df.dtypes.to_dict(),
            'missing_values': df.isnull().sum().to_dict(),
            'numeric_summary': df.describe().to_dict() if len(df.select_dtypes(include=[np.number]).columns) > 0 else {},
            'categorical_summary': {}
        }
        
        # Add categorical column summaries
        categorical_cols = df.select_dtypes(include=['object']).columns
        for col in categorical_cols:
            summary['categorical_summary'][col] = {
                'unique_values': df[col].nunique(),
                'top_values': df[col].value_counts().head().to_dict()
            }
        
        return summary
"""
Model Training Module for Used Bike Prices Project
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Any
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.svm import SVR
from xgboost import XGBRegressor
import joblib
import warnings
warnings.filterwarnings('ignore')

class ModelTrainer:
    """Class for training and evaluating bike price prediction models"""
    
    def __init__(self, random_state: int = 42):
        self.random_state = random_state
        self.models = {}
        self.results = {}
        self.best_model = None
        self.best_score = -np.inf
        self.preprocessor = None
        
    def prepare_data(self, df: pd.DataFrame, target_col: str = 'price', 
                    test_size: float = 0.2) -> Tuple:
        """
        Prepare data for model training
        
        Args:
            df: DataFrame with features and target
            target_col: Name of target column
            test_size: Proportion of test data
            
        Returns:
            Tuple of (X_train, X_test, y_train, y_test, feature_columns)
        """
        print("Preparing data for model training...")
        
        # Separate features and target
        if target_col not in df.columns:
            raise ValueError(f"Target column '{target_col}' not found in DataFrame")
        
        X = df.drop(columns=[target_col])
        y = df[target_col]
        
        # Identify feature types
        numerical_features = X.select_dtypes(include=[np.number]).columns.tolist()
        categorical_features = X.select_dtypes(include=['object', 'category']).columns.tolist()
        
        print(f"Numerical features: {len(numerical_features)}")
        print(f"Categorical features: {len(categorical_features)}")
        print(f"Total features: {len(X.columns)}")
        
        # Create preprocessing pipeline
        numerical_transformer = StandardScaler()
        categorical_transformer = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
        
        self.preprocessor = ColumnTransformer(
            transformers=[
                ('num', numerical_transformer, numerical_features),
                ('cat', categorical_transformer, categorical_features)
            ])
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=self.random_state
        )
        
        print(f"\nData split:")
        print(f"  Training set: {X_train.shape}")
        print(f"  Test set: {X_test.shape}")
        
        return X_train, X_test, y_train, y_test, X.columns.tolist()
    
    def get_model_pipeline(self, model_name: str, model: Any) -> Pipeline:
        """
        Create pipeline for a specific model
        
        Args:
            model_name: Name of the model
            model: Model instance
            
        Returns:
            Pipeline with preprocessing and model
        """
        return Pipeline(steps=[
            ('preprocessor', self.preprocessor),
            ('model', model)
        ])
    
    def train_baseline_models(self, X_train: pd.DataFrame, X_test: pd.DataFrame,
                            y_train: pd.Series, y_test: pd.Series) -> Dict:
        """
        Train baseline regression models
        
        Args:
            X_train: Training features
            X_test: Test features
            y_train: Training target
            y_test: Test target
            
        Returns:
            Dictionary with model results
        """
        print("\n" + "="*50)
        print("TRAINING BASELINE MODELS")
        print("="*50)
        
        # Define baseline models
        baseline_models = {
            'Linear Regression': LinearRegression(),
            'Ridge Regression': Ridge(alpha=1.0, random_state=self.random_state),
            'Lasso Regression': Lasso(alpha=0.1, random_state=self.random_state),
            'Decision Tree': DecisionTreeRegressor(random_state=self.random_state, max_depth=10),
            'Random Forest': RandomForestRegressor(
                n_estimators=100, 
                random_state=self.random_state,
                n_jobs=-1
            )
        }
        
        results = {}
        
        for name, model in baseline_models.items():
            print(f"\nTraining {name}...")
            
            try:
                # Create and train pipeline
                pipeline = self.get_model_pipeline(name, model)
                pipeline.fit(X_train, y_train)
                
                # Make predictions
                y_pred_train = pipeline.predict(X_train)
                y_pred_test = pipeline.predict(X_test)
                
                # Calculate metrics
                train_mae = mean_absolute_error(y_train, y_pred_train)
                test_mae = mean_absolute_error(y_test, y_pred_test)
                
                train_mse = mean_squared_error(y_train, y_pred_train)
                test_mse = mean_squared_error(y_test, y_pred_test)
                
                train_rmse = np.sqrt(train_mse)
                test_rmse = np.sqrt(test_mse)
                
                train_r2 = r2_score(y_train, y_pred_train)
                test_r2 = r2_score(y_test, y_pred_test)
                
                # Store results
                results[name] = {
                    'model': pipeline,
                    'train_mae': train_mae,
                    'test_mae': test_mae,
                    'train_mse': train_mse,
                    'test_mse': test_mse,
                    'train_rmse': train_rmse,
                    'test_rmse': test_rmse,
                    'train_r2': train_r2,
                    'test_r2': test_r2,
                    'y_pred_train': y_pred_train,
                    'y_pred_test': y_pred_test
                }
                
                # Store model
                self.models[name] = pipeline
                
                print(f"  Train R²: {train_r2:.4f}")
                print(f"  Test R²:  {test_r2:.4f}")
                print(f"  Test RMSE: ₹{test_rmse:,.2f}")
                print(f"  Test MAE:  ₹{test_mae:,.2f}")
                
            except Exception as e:
                print(f"  Error training {name}: {e}")
                continue
        
        self.results = results
        return results
    
    def train_advanced_models(self, X_train: pd.DataFrame, X_test: pd.DataFrame,
                            y_train: pd.Series, y_test: pd.Series) -> Dict:
        """
        Train advanced regression models
        
        Args:
            X_train: Training features
            X_test: Test features
            y_train: Training target
            y_test: Test target
            
        Returns:
            Dictionary with model results
        """
        print("\n" + "="*50)
        print("TRAINING ADVANCED MODELS")
        print("="*50)
        
        # Define advanced models
        advanced_models = {
            'Gradient Boosting': GradientBoostingRegressor(
                n_estimators=100,
                random_state=self.random_state
            ),
            'XGBoost': XGBRegressor(
                n_estimators=100,
                random_state=self.random_state,
                n_jobs=-1,
                verbosity=0
            ),
            'ElasticNet': ElasticNet(
                alpha=0.1,
                l1_ratio=0.5,
                random_state=self.random_state
            ),
            'Support Vector Regression': SVR(
                kernel='rbf',
                C=1.0,
                epsilon=0.1
            )
        }
        
        for name, model in advanced_models.items():
            print(f"\nTraining {name}...")
            
            try:
                # Create and train pipeline
                pipeline = self.get_model_pipeline(name, model)
                pipeline.fit(X_train, y_train)
                
                # Make predictions
                y_pred_train = pipeline.predict(X_train)
                y_pred_test = pipeline.predict(X_test)
                
                # Calculate metrics
                train_mae = mean_absolute_error(y_train, y_pred_train)
                test_mae = mean_absolute_error(y_test, y_pred_test)
                
                train_mse = mean_squared_error(y_train, y_pred_train)
                test_mse = mean_squared_error(y_test, y_pred_test)
                
                train_rmse = np.sqrt(train_mse)
                test_rmse = np.sqrt(test_mse)
                
                train_r2 = r2_score(y_train, y_pred_train)
                test_r2 = r2_score(y_test, y_pred_test)
                
                # Store results
                self.results[name] = {
                    'model': pipeline,
                    'train_mae': train_mae,
                    'test_mae': test_mae,
                    'train_mse': train_mse,
                    'test_mse': test_mse,
                    'train_rmse': train_rmse,
                    'test_rmse': test_rmse,
                    'train_r2': train_r2,
                    'test_r2': test_r2,
                    'y_pred_train': y_pred_train,
                    'y_pred_test': y_pred_test
                }
                
                # Store model
                self.models[name] = pipeline
                
                print(f"  Train R²: {train_r2:.4f}")
                print(f"  Test R²:  {test_r2:.4f}")
                print(f"  Test RMSE: ₹{test_rmse:,.2f}")
                print(f"  Test MAE:  ₹{test_mae:,.2f}")
                
                # Update best model
                if test_r2 > self.best_score:
                    self.best_score = test_r2
                    self.best_model = pipeline
                
            except Exception as e:
                print(f"  Error training {name}: {e}")
                continue
        
        return self.results
    
    def perform_hyperparameter_tuning(self, X_train: pd.DataFrame, X_test: pd.DataFrame,
                                    y_train: pd.Series, y_test: pd.Series) -> Dict:
        """
        Perform hyperparameter tuning for best models
        
        Args:
            X_train: Training features
            X_test: Test features
            y_train: Training target
            y_test: Test target
            
        Returns:
            Dictionary with tuned model results
        """
        print("\n" + "="*50)
        print("HYPERPARAMETER TUNING")
        print("="*50)
        
        # Define parameter grids for different models
        param_grids = {
            'Random Forest': {
                'model__n_estimators': [50, 100, 200],
                'model__max_depth': [None, 10, 20, 30],
                'model__min_samples_split': [2, 5, 10],
                'model__min_samples_leaf': [1, 2, 4]
            },
            'Gradient Boosting': {
                'model__n_estimators': [50, 100, 200],
                'model__learning_rate': [0.01, 0.1, 0.2],
                'model__max_depth': [3, 5, 7],
                'model__min_samples_split': [2, 5, 10]
            },
            'XGBoost': {
                'model__n_estimators': [50, 100, 200],
                'model__max_depth': [3, 5, 7],
                'model__learning_rate': [0.01, 0.1, 0.2],
                'model__subsample': [0.8, 1.0],
                'model__colsample_bytree': [0.8, 1.0]
            }
        }
        
        tuned_results = {}
        
        for model_name in ['Random Forest', 'Gradient Boosting', 'XGBoost']:
            if model_name in self.models:
                print(f"\nTuning {model_name}...")
                
                try:
                    # Get base model
                    if model_name == 'Random Forest':
                        base_model = RandomForestRegressor(random_state=self.random_state, n_jobs=-1)
                    elif model_name == 'Gradient Boosting':
                        base_model = GradientBoostingRegressor(random_state=self.random_state)
                    else:  # XGBoost
                        base_model = XGBRegressor(random_state=self.random_state, n_jobs=-1, verbosity=0)
                    
                    # Create pipeline
                    pipeline = Pipeline(steps=[
                        ('preprocessor', self.preprocessor),
                        ('model', base_model)
                    ])
                    
                    # Perform grid search
                    grid_search = GridSearchCV(
                        pipeline,
                        param_grids[model_name],
                        cv=5,
                        scoring='r2',
                        n_jobs=-1,
                        verbose=0
                    )
                    
                    grid_search.fit(X_train, y_train)
                    
                    # Get best model
                    best_model = grid_search.best_estimator_
                    best_params = grid_search.best_params_
                    
                    # Make predictions
                    y_pred_train = best_model.predict(X_train)
                    y_pred_test = best_model.predict(X_test)
                    
                    # Calculate metrics
                    train_r2 = r2_score(y_train, y_pred_train)
                    test_r2 = r2_score(y_test, y_pred_test)
                    test_rmse = np.sqrt(mean_squared_error(y_test, y_pred_test))
                    test_mae = mean_absolute_error(y_test, y_pred_test)
                    
                    # Store results
                    tuned_name = f"{model_name} (Tuned)"
                    tuned_results[tuned_name] = {
                        'model': best_model,
                        'best_params': best_params,
                        'train_r2': train_r2,
                        'test_r2': test_r2,
                        'test_rmse': test_rmse,
                        'test_mae': test_mae,
                        'y_pred_test': y_pred_test
                    }
                    
                    # Update best model if better
                    if test_r2 > self.best_score:
                        self.best_score = test_r2
                        self.best_model = best_model
                        print(f"  New best model: {tuned_name}")
                    
                    print(f"  Best Parameters: {best_params}")
                    print(f"  Best CV Score: {grid_search.best_score_:.4f}")
                    print(f"  Test R²: {test_r2:.4f}")
                    print(f"  Test RMSE: ₹{test_rmse:,.2f}")
                    
                except Exception as e:
                    print(f"  Error tuning {model_name}: {e}")
                    continue
        
        # Update results with tuned models
        self.results.update(tuned_results)
        return tuned_results
    
    def evaluate_models(self) -> pd.DataFrame:
        """
        Create comparison table of all models
        
        Returns:
            DataFrame with model comparison
        """
        if not self.results:
            print("No models have been trained yet")
            return pd.DataFrame()
        
        comparison_data = []
        
        for model_name, result in self.results.items():
            comparison_data.append({
                'Model': model_name,
                'Train R²': result['train_r2'],
                'Test R²': result['test_r2'],
                'Test RMSE': result['test_rmse'],
                'Test MAE': result['test_mae'],
                'Test MSE': result['test_mse']
            })
        
        comparison_df = pd.DataFrame(comparison_data)
        comparison_df = comparison_df.sort_values('Test R²', ascending=False)
        
        print("\n" + "="*50)
        print("MODEL COMPARISON")
        print("="*50)
        print(comparison_df.to_string(index=False, float_format=lambda x: f'{x:.4f}'))
        
        return comparison_df
    
    def plot_model_comparison(self, save_path: str = None) -> None:
        """
        Plot model comparison
        
        Args:
            save_path: Path to save the plot
        """
        if not self.results:
            print("No models to compare")
            return
        
        comparison_df = self.evaluate_models()
        if comparison_df.empty:
            return
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # 1. R² Score Comparison
        ax1 = axes[0, 0]
        bars1 = ax1.barh(range(len(comparison_df)), comparison_df['Test R²'].values)
        ax1.set_yticks(range(len(comparison_df)))
        ax1.set_yticklabels(comparison_df['Model'])
        ax1.set_xlabel('R² Score')
        ax1.set_title('Model Comparison: R² Score', fontsize=12, fontweight='bold')
        ax1.invert_yaxis()  # Highest R² at top
        
        # Add R² values on bars
        for i, (bar, r2) in enumerate(zip(bars1, comparison_df['Test R²'].values)):
            ax1.text(bar.get_width() + 0.01, bar.get_y() + bar.get_height()/2,
                   f'{r2:.3f}', va='center', fontsize=9)
        
        # 2. RMSE Comparison
        ax2 = axes[0, 1]
        bars2 = ax2.barh(range(len(comparison_df)), comparison_df['Test RMSE'].values)
        ax2.set_yticks(range(len(comparison_df)))
        ax2.set_yticklabels(comparison_df['Model'])
        ax2.set_xlabel('RMSE (₹)')
        ax2.set_title('Model Comparison: RMSE', fontsize=12, fontweight='bold')
        ax2.invert_yaxis()
        
        # Add RMSE values on bars
        for i, (bar, rmse) in enumerate(zip(bars2, comparison_df['Test RMSE'].values)):
            ax2.text(bar.get_width() + 1000, bar.get_y() + bar.get_height()/2,
                   f'₹{rmse:,.0f}', va='center', fontsize=9)
        
        # 3. Actual vs Predicted for best model
        ax3 = axes[1, 0]
        if self.best_model is not None:
            # Get predictions from best model
            best_model_name = comparison_df.iloc[0]['Model']
            best_result = self.results[best_model_name]
            
            y_pred = best_result['y_pred_test']
            
            # We need y_test, but we don't have it stored globally
            # This is a limitation - in practice you'd need to pass it
            ax3.scatter(range(len(y_pred)), y_pred, alpha=0.6, s=20, 
                       label='Predictions', color='blue')
            ax3.set_xlabel('Sample Index')
            ax3.set_ylabel('Predicted Price (₹)')
            ax3.set_title(f'Predictions from Best Model: {best_model_name}', 
                         fontsize=12, fontweight='bold')
            ax3.legend()
            ax3.grid(True, alpha=0.3)
        
        # 4. Error Distribution for best model
        ax4 = axes[1, 1]
        if self.best_model is not None and 'y_pred_test' in best_result:
            # Calculate errors (absolute percentage error)
            # Note: We need y_test for this, which we don't have
            # This is simplified - in practice you'd calculate actual errors
            ax4.text(0.5, 0.5, 'Error distribution plot\nrequires actual y_test values',
                   ha='center', va='center', transform=ax4.transAxes)
            ax4.set_title('Error Analysis', fontsize=12, fontweight='bold')
        
        plt.suptitle('Model Performance Comparison', fontsize=16, fontweight='bold', y=1.02)
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.show()
    
    def plot_feature_importance(self, model_name: str, feature_names: List[str], 
                              top_n: int = 15, save_path: str = None) -> None:
        """
        Plot feature importance for tree-based models
        
        Args:
            model_name: Name of the model
            feature_names: List of feature names
            top_n: Number of top features to show
            save_path: Path to save the plot
        """
        if model_name not in self.models:
            print(f"Model '{model_name}' not found")
            return
        
        model = self.models[model_name]
        
        # Check if model has feature_importances_ attribute
        if hasattr(model.named_steps['model'], 'feature_importances_'):
            # Get feature importances
            importances = model.named_steps['model'].feature_importances_
            
            # Get feature names after preprocessing
            # This is complex with ColumnTransformer - simplified approach
            if len(importances) == len(feature_names):
                # Create DataFrame
                feature_imp_df = pd.DataFrame({
                    'Feature': feature_names,
                    'Importance': importances
                }).sort_values('Importance', ascending=False).head(top_n)
                
                # Plot
                plt.figure(figsize=(12, 8))
                bars = plt.barh(range(len(feature_imp_df)), 
                              feature_imp_df['Importance'].values)
                plt.yticks(range(len(feature_imp_df)), feature_imp_df['Feature'])
                plt.xlabel('Feature Importance')
                plt.title(f'Top {top_n} Feature Importances - {model_name}', 
                         fontsize=14, fontweight='bold')
                plt.gca().invert_yaxis()
                
                # Add importance values
                for i, (bar, imp) in enumerate(zip(bars, feature_imp_df['Importance'].values)):
                    plt.text(bar.get_width() + 0.001, bar.get_y() + bar.get_height()/2,
                           f'{imp:.4f}', va='center', fontsize=9)
                
                plt.tight_layout()
                
                if save_path:
                    plt.savefig(save_path, dpi=300, bbox_inches='tight')
                plt.show()
            else:
                print("Feature importance dimension mismatch")
        else:
            print(f"Model '{model_name}' does not have feature importances")
    
    def save_best_model(self, filepath: str = 'models/best_model.pkl') -> None:
        """
        Save the best model to disk
        
        Args:
            filepath: Path to save the model
        """
        if self.best_model is None:
            print("No best model to save")
            return
        
        # Create directory if it doesn't exist
        import os
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        
        # Save model
        joblib.dump(self.best_model, filepath)
        print(f"Best model saved to: {filepath}")
        
        # Also save preprocessing pipeline separately
        preprocessor_path = 'models/preprocessor.pkl'
        joblib.dump(self.preprocessor, preprocessor_path)
        print(f"Preprocessor saved to: {preprocessor_path}")
    
    def load_model(self, model_path: str = 'models/best_model.pkl') -> Any:
        """
        Load a saved model
        
        Args:
            model_path: Path to saved model
            
        Returns:
            Loaded model
        """
        try:
            model = joblib.load(model_path)
            print(f"Model loaded from: {model_path}")
            return model
        except FileNotFoundError:
            print(f"Model file not found: {model_path}")
            return None
    
    def make_predictions(self, model: Any, X_new: pd.DataFrame) -> np.ndarray:
        """
        Make predictions using a trained model
        
        Args:
            model: Trained model
            X_new: New data for prediction
            
        Returns:
            Array of predictions
        """
        try:
            predictions = model.predict(X_new)
            print(f"Made predictions for {len(predictions)} samples")
            return predictions
        except Exception as e:
            print(f"Error making predictions: {e}")
            return None
    
    def create_prediction_report(self, y_true: pd.Series, y_pred: np.ndarray, 
                               model_name: str = 'Model') -> Dict:
        """
        Create detailed prediction report
        
        Args:
            y_true: Actual values
            y_pred: Predicted values
            model_name: Name of the model
            
        Returns:
            Dictionary with detailed metrics
        """
        # Calculate metrics
        mae = mean_absolute_error(y_true, y_pred)
        mse = mean_squared_error(y_true, y_pred)
        rmse = np.sqrt(mse)
        r2 = r2_score(y_true, y_pred)
        
        # Calculate percentage errors
        percentage_errors = np.abs((y_true - y_pred) / y_true) * 100
        mean_percentage_error = np.mean(percentage_errors)
        median_percentage_error = np.median(percentage_errors)
        
        # Create report
        report = {
            'model_name': model_name,
            'r2_score': r2,
            'mae': mae,
            'mse': mse,
            'rmse': rmse,
            'mean_percentage_error': mean_percentage_error,
            'median_percentage_error': median_percentage_error,
            'predictions': y_pred,
            'errors': y_true - y_pred,
            'percentage_errors': percentage_errors
        }
        
        print(f"\n{model_name} Prediction Report:")
        print(f"  R² Score: {r2:.4f}")
        print(f"  MAE: ₹{mae:,.2f}")
        print(f"  RMSE: ₹{rmse:,.2f}")
        print(f"  Mean Percentage Error: {mean_percentage_error:.2f}%")
        print(f"  Median Percentage Error: {median_percentage_error:.2f}%")
        
        return report
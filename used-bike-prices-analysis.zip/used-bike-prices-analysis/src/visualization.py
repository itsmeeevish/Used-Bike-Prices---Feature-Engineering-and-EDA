"""
Visualization Module for Used Bike Prices Project
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from typing import List, Tuple, Dict
import os

class DataVisualizer:
    """Class for creating visualizations for bike price analysis"""
    
    def __init__(self, output_dir: str = 'reports/visualizations'):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
        # Set style
        plt.style.use('seaborn-v0_8')
        sns.set_palette("husl")
        
    def plot_price_distribution(self, df: pd.DataFrame, save: bool = True) -> None:
        """
        Plot price distribution with different transformations
        
        Args:
            df: DataFrame containing 'price' column
            save: Whether to save the plot
        """
        if 'price' not in df.columns:
            print("Error: 'price' column not found in DataFrame")
            return
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # Original price distribution
        ax1 = axes[0, 0]
        sns.histplot(df['price'], kde=True, bins=50, ax=ax1)
        ax1.set_title('Original Price Distribution', fontsize=14, fontweight='bold')
        ax1.set_xlabel('Price (INR)')
        ax1.set_ylabel('Frequency')
        
        # Add statistics
        mean_price = df['price'].mean()
        median_price = df['price'].median()
        ax1.axvline(mean_price, color='red', linestyle='--', 
                   label=f'Mean: ₹{mean_price:,.0f}')
        ax1.axvline(median_price, color='green', linestyle='--', 
                   label=f'Median: ₹{median_price:,.0f}')
        ax1.legend()
        
        # Log-transformed price
        ax2 = axes[0, 1]
        log_price = np.log1p(df['price'])
        sns.histplot(log_price, kde=True, bins=50, ax=ax2)
        ax2.set_title('Log-Transformed Price Distribution', fontsize=14, fontweight='bold')
        ax2.set_xlabel('log(Price + 1)')
        ax2.set_ylabel('Frequency')
        
        # Box plot
        ax3 = axes[1, 0]
        sns.boxplot(y=df['price'], ax=ax3)
        ax3.set_title('Price Box Plot', fontsize=14, fontweight='bold')
        ax3.set_ylabel('Price (INR)')
        
        # Q-Q plot
        ax4 = axes[1, 1]
        from scipy import stats
        stats.probplot(df['price'], dist="norm", plot=ax4)
        ax4.set_title('Q-Q Plot of Price', fontsize=14, fontweight='bold')
        ax4.set_xlabel('Theoretical Quantiles')
        ax4.set_ylabel('Ordered Values')
        
        plt.suptitle('Price Distribution Analysis', fontsize=16, fontweight='bold', y=1.02)
        plt.tight_layout()
        
        if save:
            plt.savefig(f'{self.output_dir}/price_distribution.png', 
                       dpi=300, bbox_inches='tight')
        plt.show()
        
    def plot_numerical_features(self, df: pd.DataFrame, save: bool = True) -> None:
        """
        Plot distribution of numerical features
        
        Args:
            df: DataFrame with numerical columns
            save: Whether to save the plot
        """
        numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        
        # Remove price if present (handled separately)
        if 'price' in numerical_cols:
            numerical_cols.remove('price')
        
        if not numerical_cols:
            print("No numerical columns found")
            return
        
        # Select top 8 numerical features if many
        if len(numerical_cols) > 8:
            numerical_cols = numerical_cols[:8]
        
        n_cols = 3
        n_rows = (len(numerical_cols) + n_cols - 1) // n_cols
        
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(15, 4*n_rows))
        axes = axes.flatten()
        
        for idx, col in enumerate(numerical_cols):
            if idx < len(axes):
                # Histogram with KDE
                sns.histplot(df[col].dropna(), kde=True, bins=30, ax=axes[idx])
                
                # Add statistics
                mean_val = df[col].mean()
                median_val = df[col].median()
                
                axes[idx].axvline(mean_val, color='red', linestyle='--', 
                                alpha=0.7, label=f'Mean: {mean_val:.2f}')
                axes[idx].axvline(median_val, color='green', linestyle='--', 
                                alpha=0.7, label=f'Median: {median_val:.2f}')
                
                axes[idx].set_title(f'{col} Distribution', fontsize=12, fontweight='bold')
                axes[idx].set_xlabel(col)
                axes[idx].set_ylabel('Frequency')
                axes[idx].legend(fontsize=8)
        
        # Hide empty subplots
        for idx in range(len(numerical_cols), len(axes)):
            axes[idx].set_visible(False)
        
        plt.suptitle('Numerical Features Distribution', fontsize=16, fontweight='bold', y=1.02)
        plt.tight_layout()
        
        if save:
            plt.savefig(f'{self.output_dir}/numerical_features_distribution.png', 
                       dpi=300, bbox_inches='tight')
        plt.show()
        
    def plot_categorical_features(self, df: pd.DataFrame, save: bool = True) -> None:
        """
        Plot distribution of categorical features
        
        Args:
            df: DataFrame with categorical columns
            save: Whether to save the plot
        """
        categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
        
        if not categorical_cols:
            print("No categorical columns found")
            return
        
        # Select top 6 categorical features if many
        if len(categorical_cols) > 6:
            categorical_cols = categorical_cols[:6]
        
        n_cols = 2
        n_rows = (len(categorical_cols) + n_cols - 1) // n_cols
        
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(15, 5*n_rows))
        
        if n_rows == 1:
            axes = axes.reshape(1, -1)
        
        for idx, col in enumerate(categorical_cols):
            row = idx // n_cols
            col_idx = idx % n_cols
            
            if row < n_rows and col_idx < n_cols:
                # Get value counts (top 10 categories)
                value_counts = df[col].value_counts().head(10)
                
                # Create bar plot
                bars = axes[row, col_idx].bar(range(len(value_counts)), value_counts.values)
                axes[row, col_idx].set_title(f'{col} Distribution (Top 10)', 
                                           fontsize=12, fontweight='bold')
                axes[row, col_idx].set_xlabel(col)
                axes[row, col_idx].set_ylabel('Count')
                axes[row, col_idx].set_xticks(range(len(value_counts)))
                axes[row, col_idx].set_xticklabels(value_counts.index, 
                                                 rotation=45, ha='right')
                
                # Add count labels on bars
                for bar_idx, (bar, count) in enumerate(zip(bars, value_counts.values)):
                    height = bar.get_height()
                    axes[row, col_idx].text(bar.get_x() + bar.get_width()/2., 
                                          height + 0.1,
                                          f'{count:,}',
                                          ha='center', va='bottom', fontsize=9)
        
        # Hide empty subplots
        for idx in range(len(categorical_cols), n_rows * n_cols):
            row = idx // n_cols
            col_idx = idx % n_cols
            axes[row, col_idx].set_visible(False)
        
        plt.suptitle('Categorical Features Distribution', fontsize=16, fontweight='bold', y=1.02)
        plt.tight_layout()
        
        if save:
            plt.savefig(f'{self.output_dir}/categorical_features_distribution.png', 
                       dpi=300, bbox_inches='tight')
        plt.show()
        
    def plot_correlation_matrix(self, df: pd.DataFrame, save: bool = True) -> None:
        """
        Plot correlation matrix for numerical features
        
        Args:
            df: DataFrame with numerical columns
            save: Whether to save the plot
        """
        numerical_df = df.select_dtypes(include=[np.number])
        
        if numerical_df.shape[1] < 2:
            print("Not enough numerical columns for correlation matrix")
            return
        
        # Calculate correlation matrix
        corr_matrix = numerical_df.corr()
        
        plt.figure(figsize=(12, 10))
        
        # Create heatmap
        mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
        sns.heatmap(corr_matrix, mask=mask, annot=True, fmt='.2f', 
                   cmap='coolwarm', center=0, square=True,
                   cbar_kws={"shrink": 0.8}, linewidths=0.5)
        
        plt.title('Correlation Matrix of Numerical Features', 
                 fontsize=16, fontweight='bold', pad=20)
        plt.tight_layout()
        
        if save:
            plt.savefig(f'{self.output_dir}/correlation_matrix.png', 
                       dpi=300, bbox_inches='tight')
        plt.show()
        
        # Print top correlations with price
        if 'price' in corr_matrix.columns:
            print("\nTop 10 Correlations with Price:")
            price_corr = corr_matrix['price'].sort_values(ascending=False)
            for feature, correlation in price_corr.head(11).items():  # 11 because price with itself is 1
                if feature != 'price':
                    print(f"  {feature}: {correlation:.3f}")
    
    def plot_price_vs_features(self, df: pd.DataFrame, save: bool = True) -> None:
        """
        Plot price vs other important features
        
        Args:
            df: DataFrame with features and price
            save: Whether to save the plot
        """
        if 'price' not in df.columns:
            print("Error: 'price' column not found")
            return
        
        # Select important numerical features (excluding price)
        numerical_features = df.select_dtypes(include=[np.number]).columns.tolist()
        if 'price' in numerical_features:
            numerical_features.remove('price')
        
        # Select top features for plotting
        features_to_plot = numerical_features[:9]  # Plot up to 9 features
        
        n_cols = 3
        n_rows = (len(features_to_plot) + n_cols - 1) // n_cols
        
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(15, 4*n_rows))
        
        if n_rows == 1:
            axes = axes.reshape(1, -1)
        
        for idx, feature in enumerate(features_to_plot):
            row = idx // n_cols
            col_idx = idx % n_cols
            
            if row < n_rows and col_idx < n_cols:
                # Scatter plot with regression line
                sns.regplot(x=feature, y='price', data=df, 
                          scatter_kws={'alpha': 0.5, 's': 20},
                          line_kws={'color': 'red', 'linewidth': 2},
                          ax=axes[row, col_idx])
                
                axes[row, col_idx].set_title(f'Price vs {feature}', 
                                           fontsize=12, fontweight='bold')
                axes[row, col_idx].set_xlabel(feature)
                axes[row, col_idx].set_ylabel('Price (INR)')
                
                # Calculate and display correlation
                correlation = df[[feature, 'price']].corr().iloc[0, 1]
                axes[row, col_idx].text(0.05, 0.95, 
                                      f'Corr: {correlation:.3f}',
                                      transform=axes[row, col_idx].transAxes,
                                      fontsize=10, verticalalignment='top',
                                      bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        
        # Hide empty subplots
        for idx in range(len(features_to_plot), n_rows * n_cols):
            row = idx // n_cols
            col_idx = idx % n_cols
            axes[row, col_idx].set_visible(False)
        
        plt.suptitle('Price Relationship with Key Features', 
                    fontsize=16, fontweight='bold', y=1.02)
        plt.tight_layout()
        
        if save:
            plt.savefig(f'{self.output_dir}/price_vs_features.png', 
                       dpi=300, bbox_inches='tight')
        plt.show()
    
    def plot_brand_analysis(self, df: pd.DataFrame, save: bool = True) -> None:
        """
        Analyze and visualize bike brands
        
        Args:
            df: DataFrame with 'brand' and 'price' columns
            save: Whether to save the plot
        """
        if 'brand' not in df.columns or 'price' not in df.columns:
            print("Error: 'brand' or 'price' column not found")
            return
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # 1. Brand count (top 15)
        brand_counts = df['brand'].value_counts().head(15)
        axes[0, 0].barh(range(len(brand_counts)), brand_counts.values)
        axes[0, 0].set_yticks(range(len(brand_counts)))
        axes[0, 0].set_yticklabels(brand_counts.index)
        axes[0, 0].set_title('Top 15 Brands by Count', fontsize=12, fontweight='bold')
        axes[0, 0].set_xlabel('Number of Bikes')
        
        # Add count labels
        for i, count in enumerate(brand_counts.values):
            axes[0, 0].text(count + 10, i, f'{count:,}', va='center')
        
        # 2. Average price by brand (top 15)
        avg_price_by_brand = df.groupby('brand')['price'].mean().sort_values(ascending=False).head(15)
        axes[0, 1].barh(range(len(avg_price_by_brand)), avg_price_by_brand.values)
        axes[0, 1].set_yticks(range(len(avg_price_by_brand)))
        axes[0, 1].set_yticklabels(avg_price_by_brand.index)
        axes[0, 1].set_title('Top 15 Brands by Average Price', fontsize=12, fontweight='bold')
        axes[0, 1].set_xlabel('Average Price (INR)')
        
        # Add price labels
        for i, price in enumerate(avg_price_by_brand.values):
            axes[0, 1].text(price + 10000, i, f'₹{price:,.0f}', va='center')
        
        # 3. Box plot of prices by top brands
        top_brands = brand_counts.head(10).index.tolist()
        top_brands_df = df[df['brand'].isin(top_brands)]
        
        sns.boxplot(x='price', y='brand', data=top_brands_df, 
                   ax=axes[1, 0], order=top_brands)
        axes[1, 0].set_title('Price Distribution by Top Brands', 
                           fontsize=12, fontweight='bold')
        axes[1, 0].set_xlabel('Price (INR)')
        axes[1, 0].set_ylabel('Brand')
        
        # 4. Brand vs Model Year heatmap
        if 'model_year' in df.columns:
            brand_year_price = df.pivot_table(
                values='price', 
                index='brand', 
                columns='model_year', 
                aggfunc='mean'
            ).loc[top_brands]
            
            # Only show if we have enough data
            if not brand_year_price.empty:
                sns.heatmap(brand_year_price, cmap='YlOrRd', 
                          cbar_kws={'label': 'Average Price'},
                          ax=axes[1, 1])
                axes[1, 1].set_title('Average Price: Brand vs Model Year', 
                                   fontsize=12, fontweight='bold')
                axes[1, 1].set_xlabel('Model Year')
                axes[1, 1].set_ylabel('Brand')
            else:
                axes[1, 1].text(0.5, 0.5, 'Insufficient data\nfor heatmap',
                              ha='center', va='center', 
                              transform=axes[1, 1].transAxes)
                axes[1, 1].set_title('Brand vs Model Year Analysis', 
                                   fontsize=12, fontweight='bold')
        
        plt.suptitle('Brand Analysis', fontsize=16, fontweight='bold', y=1.02)
        plt.tight_layout()
        
        if save:
            plt.savefig(f'{self.output_dir}/brand_analysis.png', 
                       dpi=300, bbox_inches='tight')
        plt.show()
    
    def plot_model_year_analysis(self, df: pd.DataFrame, save: bool = True) -> None:
        """
        Analyze and visualize bike model years
        
        Args:
            df: DataFrame with 'model_year' and 'price' columns
            save: Whether to save the plot
        """
        if 'model_year' not in df.columns or 'price' not in df.columns:
            print("Error: 'model_year' or 'price' column not found")
            return
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # 1. Count of bikes by model year
        year_counts = df['model_year'].value_counts().sort_index()
        axes[0, 0].plot(year_counts.index, year_counts.values, marker='o', linewidth=2)
        axes[0, 0].fill_between(year_counts.index, year_counts.values, alpha=0.3)
        axes[0, 0].set_title('Number of Bikes by Model Year', 
                           fontsize=12, fontweight='bold')
        axes[0, 0].set_xlabel('Model Year')
        axes[0, 0].set_ylabel('Count')
        axes[0, 0].grid(True, alpha=0.3)
        
        # 2. Average price by model year
        avg_price_by_year = df.groupby('model_year')['price'].mean()
        axes[0, 1].plot(avg_price_by_year.index, avg_price_by_year.values, 
                       marker='o', linewidth=2, color='orange')
        axes[0, 1].fill_between(avg_price_by_year.index, avg_price_by_year.values, 
                               alpha=0.3, color='orange')
        axes[0, 1].set_title('Average Price by Model Year', 
                           fontsize=12, fontweight='bold')
        axes[0, 1].set_xlabel('Model Year')
        axes[0, 1].set_ylabel('Average Price (INR)')
        axes[0, 1].grid(True, alpha=0.3)
        
        # 3. Price distribution by year (box plot)
        recent_years = sorted(df['model_year'].unique())[-10:]  # Last 10 years
        recent_df = df[df['model_year'].isin(recent_years)]
        
        sns.boxplot(x='model_year', y='price', data=recent_df, ax=axes[1, 0])
        axes[1, 0].set_title('Price Distribution by Model Year (Last 10 Years)', 
                           fontsize=12, fontweight='bold')
        axes[1, 0].set_xlabel('Model Year')
        axes[1, 0].set_ylabel('Price (INR)')
        axes[1, 0].tick_params(axis='x', rotation=45)
        
        # 4. Scatter plot: Year vs Price with regression
        sns.regplot(x='model_year', y='price', data=df, 
                   scatter_kws={'alpha': 0.5, 's': 20},
                   line_kws={'color': 'red', 'linewidth': 2},
                   ax=axes[1, 1])
        axes[1, 1].set_title('Price vs Model Year with Trend Line', 
                           fontsize=12, fontweight='bold')
        axes[1, 1].set_xlabel('Model Year')
        axes[1, 1].set_ylabel('Price (INR)')
        
        plt.suptitle('Model Year Analysis', fontsize=16, fontweight='bold', y=1.02)
        plt.tight_layout()
        
        if save:
            plt.savefig(f'{self.output_dir}/model_year_analysis.png', 
                       dpi=300, bbox_inches='tight')
        plt.show()
    
    def create_comprehensive_report(self, df: pd.DataFrame) -> None:
        """
        Create comprehensive visualization report
        
        Args:
            df: DataFrame to analyze
        """
        print("Creating comprehensive visualization report...")
        
        # 1. Price analysis
        self.plot_price_distribution(df, save=True)
        
        # 2. Numerical features
        self.plot_numerical_features(df, save=True)
        
        # 3. Categorical features
        self.plot_categorical_features(df, save=True)
        
        # 4. Correlation analysis
        self.plot_correlation_matrix(df, save=True)
        
        # 5. Price vs features
        self.plot_price_vs_features(df, save=True)
        
        # 6. Brand analysis (if brand column exists)
        if 'brand' in df.columns:
            self.plot_brand_analysis(df, save=True)
        
        # 7. Model year analysis (if model_year column exists)
        if 'model_year' in df.columns:
            self.plot_model_year_analysis(df, save=True)
        
        print(f"\nAll visualizations saved to: {self.output_dir}/")
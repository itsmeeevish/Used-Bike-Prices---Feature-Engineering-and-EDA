"""
Used Bike Prices Analysis - Feature Engineering and EDA
A comprehensive machine learning project for predicting used bike prices
"""

__version__ = "1.0.0"
__author__ = "Data Science Team"
__description__ = "Used Bike Prices Prediction with Feature Engineering and EDA"

# Import main classes
from .data_preprocessing import DataPreprocessor
from .feature_engineering import FeatureEngineer
from .visualization import DataVisualizer
from .model_training import ModelTrainer

# Import utility functions
from .data_preprocessing import (
    load_data,
    clean_column_names,
    handle_missing_values,
    extract_cc_from_model,
    extract_brand_from_model,
    clean_power_column,
    clean_kms_driven,
    clean_mileage
)

from .feature_engineering import (
    create_bike_age,
    create_power_to_cc_ratio,
    create_mileage_category,
    create_power_category,
    create_owner_encoding,
    create_location_features,
    create_time_based_features,
    create_interaction_features
)

from .visualization import (
    plot_price_distribution,
    plot_numerical_features,
    plot_categorical_features,
    plot_correlation_matrix,
    plot_price_vs_features,
    plot_brand_analysis,
    plot_model_year_analysis
)

from .model_training import (
    prepare_data,
    train_baseline_models,
    train_advanced_models,
    perform_hyperparameter_tuning,
    evaluate_models,
    plot_model_comparison,
    plot_feature_importance,
    save_best_model,
    load_model,
    make_predictions,
    create_prediction_report
)

# Define what gets imported with "from src import *"
__all__ = [
    # Main classes
    "DataPreprocessor",
    "FeatureEngineer", 
    "DataVisualizer",
    "ModelTrainer",
    
    # Data preprocessing functions
    "load_data",
    "clean_column_names",
    "handle_missing_values",
    "extract_cc_from_model",
    "extract_brand_from_model",
    "clean_power_column",
    "clean_kms_driven",
    "clean_mileage",
    
    # Feature engineering functions
    "create_bike_age",
    "create_power_to_cc_ratio",
    "create_mileage_category",
    "create_power_category",
    "create_owner_encoding",
    "create_location_features",
    "create_time_based_features",
    "create_interaction_features",
    
    # Visualization functions
    "plot_price_distribution",
    "plot_numerical_features",
    "plot_categorical_features",
    "plot_correlation_matrix",
    "plot_price_vs_features",
    "plot_brand_analysis",
    "plot_model_year_analysis",
    
    # Model training functions
    "prepare_data",
    "train_baseline_models",
    "train_advanced_models",
    "perform_hyperparameter_tuning",
    "evaluate_models",
    "plot_model_comparison",
    "plot_feature_importance",
    "save_best_model",
    "load_model",
    "make_predictions",
    "create_prediction_report"
]

# Package information
PACKAGE_INFO = {
    "name": "used_bike_prices_analysis",
    "version": __version__,
    "author": __author__,
    "description": __description__,
    "modules": [
        "data_preprocessing",
        "feature_engineering", 
        "visualization",
        "model_training"
    ]
}

def get_package_info():
    """Return package information"""
    return PACKAGE_INFO

def list_available_functions():
    """List all available functions in the package"""
    functions = {}
    
    # Data preprocessing
    functions['data_preprocessing'] = [
        'DataPreprocessor',
        'load_data',
        'clean_column_names',
        'handle_missing_values',
        'extract_cc_from_model',
        'extract_brand_from_model',
        'clean_power_column',
        'clean_kms_driven',
        'clean_mileage'
    ]
    
    # Feature engineering
    functions['feature_engineering'] = [
        'FeatureEngineer',
        'create_bike_age',
        'create_power_to_cc_ratio',
        'create_mileage_category',
        'create_power_category',
        'create_owner_encoding',
        'create_location_features',
        'create_time_based_features',
        'create_interaction_features'
    ]
    
    # Visualization
    functions['visualization'] = [
        'DataVisualizer',
        'plot_price_distribution',
        'plot_numerical_features',
        'plot_categorical_features',
        'plot_correlation_matrix',
        'plot_price_vs_features',
        'plot_brand_analysis',
        'plot_model_year_analysis'
    ]
    
    # Model training
    functions['model_training'] = [
        'ModelTrainer',
        'prepare_data',
        'train_baseline_models',
        'train_advanced_models',
        'perform_hyperparameter_tuning',
        'evaluate_models',
        'plot_model_comparison',
        'plot_feature_importance',
        'save_best_model',
        'load_model',
        'make_predictions',
        'create_prediction_report'
    ]
    
    return functions

def show_package_help():
    """Display help information for the package"""
    print("=" * 60)
    print("USED BIKE PRICES ANALYSIS PACKAGE")
    print("=" * 60)
    print(f"Version: {__version__}")
    print(f"Author: {__author__}")
    print(f"Description: {__description__}")
    print("\n" + "-" * 60)
    print("AVAILABLE MODULES AND FUNCTIONS:")
    print("-" * 60)
    
    functions = list_available_functions()
    
    for module, func_list in functions.items():
        print(f"\n{module.upper().replace('_', ' ')}:")
        for func in func_list:
            print(f"  - {func}")
    
    print("\n" + "-" * 60)
    print("QUICK START:")
    print("-" * 60)
    print("""
# Import the package
import src

# Create a data preprocessor
preprocessor = src.DataPreprocessor()

# Create a feature engineer
engineer = src.FeatureEngineer(current_year=2024)

# Create a visualizer
visualizer = src.DataVisualizer()

# Create a model trainer
trainer = src.ModelTrainer(random_state=42)

# Or import specific functions
from src import (
    DataPreprocessor,
    FeatureEngineer,
    DataVisualizer,
    ModelTrainer
)
    """)
    
    print("=" * 60)

# Optional: Add some utility functions that might be commonly used
def load_sample_data():
    """Load sample data for testing (if available)"""
    try:
        import pandas as pd
        data = {
            'model_name': ['Bajaj Avenger Cruise 220 2017', 'Royal Enfield Classic 350cc 2016'],
            'model_year': [2017, 2016],
            'kms_driven': ['17000 Km', '50000 Km'],
            'owner': ['first owner', 'first owner'],
            'location': ['hyderabad', 'hyderabad'],
            'mileage': ['35 kmpl', '35 kmpl'],
            'power': ['19 bhp', '19.80 bhp'],
            'price': [63500, 115000]
        }
        return pd.DataFrame(data)
    except Exception as e:
        print(f"Error loading sample data: {e}")
        return None

def check_dependencies():
    """Check if required dependencies are installed"""
    required_packages = [
        'pandas',
        'numpy',
        'matplotlib',
        'seaborn',
        'scikit-learn',
        'scipy',
        'joblib',
        'xgboost'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print("Missing dependencies:")
        for package in missing_packages:
            print(f"  - {package}")
        print("\nInstall with: pip install " + " ".join(missing_packages))
        return False
    else:
        print("All dependencies are satisfied!")
        return True

# Initialize package
print(f"Initializing Used Bike Prices Analysis v{__version__}...")

# Optional: Print welcome message when package is imported
if __name__ != "__main__":
    print(f"✅ Used Bike Prices Analysis package loaded (v{__version__})")
    print("   Type 'src.show_package_help()' for available functions")
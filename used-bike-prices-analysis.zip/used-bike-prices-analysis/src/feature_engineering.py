"""
Feature Engineering Module for Used Bike Prices Project
"""

import pandas as pd
import numpy as np
import re
from typing import List, Dict, Tuple

class FeatureEngineer:
    """Class for creating and engineering features for bike price prediction"""
    
    def __init__(self, current_year: int = 2024):
        self.current_year = current_year
        
    def extract_cc_from_model(self, model_names: pd.Series) -> pd.Series:
        """
        Extract engine capacity (cc) from model names
        
        Args:
            model_names: Series containing model names
            
        Returns:
            Series containing extracted cc values
        """
        print("Extracting CC from model names...")
        cc_values = []
        
        for model in model_names:
            if pd.isnull(model):
                cc_values.append(np.nan)
                continue
                
            model_str = str(model).lower()
            cc = np.nan
            
            # Pattern 1: Direct CC mention (e.g., "220cc", "350 cc")
            pattern1 = re.search(r'(\d+)\s*cc', model_str)
            if pattern1:
                try:
                    cc = int(pattern1.group(1))
                except:
                    pass
            
            # Pattern 2: Common CC patterns in model names
            if pd.isna(cc):
                common_patterns = {
                    '1000': 1000, '950': 950, '900': 900, '883': 883, '800': 800,
                    '765': 765, '750': 750, '650': 650, '600': 600, '500': 500,
                    '400': 400, '390': 390, '350': 350, '330': 330, '310': 310,
                    '300': 300, '295': 295, '250': 250, '220': 220, '200': 200,
                    '180': 180, '160': 160, '150': 150, '135': 135, '125': 125,
                    '110': 110, '100': 100
                }
                
                for pattern, value in common_patterns.items():
                    if pattern in model_str:
                        cc = value
                        break
            
            # Pattern 3: Numbers in model name (last resort)
            if pd.isna(cc):
                numbers = re.findall(r'\b\d{3}\b', model_str)
                if numbers:
                    try:
                        # Take the first 3-digit number
                        cc = int(numbers[0])
                    except:
                        pass
            
            cc_values.append(cc)
        
        return pd.Series(cc_values, name='cc', index=model_names.index)
    
    def extract_brand_from_model(self, model_names: pd.Series) -> pd.Series:
        """
        Extract brand name from model names
        
        Args:
            model_names: Series containing model names
            
        Returns:
            Series containing extracted brand names
        """
        print("Extracting brand names...")
        
        # Common brand mappings and corrections
        brand_mappings = {
            'yamaha': 'Yamaha',
            'royal': 'Royal Enfield',
            'bajaj': 'Bajaj',
            'hero': 'Hero',
            'honda': 'Honda',
            'tvs': 'TVS',
            'ktm': 'KTM',
            'suzuki': 'Suzuki',
            'jawa': 'Jawa',
            'mahindra': 'Mahindra',
            'kawasaki': 'Kawasaki',
            'ducati': 'Ducati',
            'harley': 'Harley-Davidson',
            'triumph': 'Triumph',
            'benelli': 'Benelli',
            'bmw': 'BMW',
            'aprilia': 'Aprilia',
            'hyosung': 'Hyosung',
            'mv': 'MV Agusta',
            'um': 'UM'
        }
        
        brands = []
        for model in model_names:
            if pd.isnull(model):
                brands.append('Unknown')
                continue
                
            model_str = str(model).lower()
            brand_found = False
            
            # Check for brand in mappings
            for brand_key, brand_name in brand_mappings.items():
                if brand_key in model_str:
                    brands.append(brand_name)
                    brand_found = True
                    break
            
            # If no brand found, use first word
            if not brand_found:
                first_word = model_str.split()[0] if model_str.split() else 'Unknown'
                brands.append(first_word.capitalize())
        
        return pd.Series(brands, name='brand', index=model_names.index)
    
    def clean_brand_names(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Clean and standardize brand names
        
        Args:
            df: DataFrame containing 'brand' column
            
        Returns:
            DataFrame with cleaned brand names
        """
        print("Cleaning brand names...")
        
        if 'brand' not in df.columns:
            return df
        
        # Brand name corrections
        corrections = {
            'Ideal': 'Jawa',
            'yamaha': 'Yamaha',
            'Royal': 'Royal Enfield',
            'Harley-Davidson': 'Harley-Davidson',
            'Harley': 'Harley-Davidson',
            'Tvs': 'TVS',
            'Hero motocorp': 'Hero',
            'Hero honda': 'Hero',
            'Bmw': 'BMW',
            'Ktm': 'KTM',
            'Suzuki': 'Suzuki'
        }
        
        df['brand'] = df['brand'].replace(corrections)
        return df
    
    def create_bike_age(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create bike age feature from model_year
        
        Args:
            df: DataFrame containing 'model_year' column
            
        Returns:
            DataFrame with 'bike_age' column
        """
        print("Creating bike age feature...")
        
        if 'model_year' not in df.columns:
            return df
        
        df['bike_age'] = self.current_year - df['model_year']
        
        # Handle unrealistic ages
        df.loc[df['bike_age'] < 0, 'bike_age'] = 0
        df.loc[df['bike_age'] > 50, 'bike_age'] = df['bike_age'].median()
        
        return df
    
    def create_power_to_cc_ratio(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create power-to-cc ratio feature
        
        Args:
            df: DataFrame containing 'power' and 'cc' columns
            
        Returns:
            DataFrame with 'power_to_cc_ratio' column
        """
        print("Creating power-to-cc ratio...")
        
        if 'power' not in df.columns or 'cc' not in df.columns:
            return df
        
        # Avoid division by zero
        df['power_to_cc_ratio'] = df['power'] / df['cc'].replace(0, np.nan)
        
        # Handle infinite values
        df.loc[df['power_to_cc_ratio'] == np.inf, 'power_to_cc_ratio'] = np.nan
        
        # Fill NaN with median
        median_ratio = df['power_to_cc_ratio'].median()
        df['power_to_cc_ratio'].fillna(median_ratio, inplace=True)
        
        return df
    
    def create_mileage_category(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create mileage categories
        
        Args:
            df: DataFrame containing 'mileage' column
            
        Returns:
            DataFrame with 'mileage_category' column
        """
        print("Creating mileage categories...")
        
        if 'mileage' not in df.columns:
            return df
        
        # Define mileage categories
        bins = [0, 30, 50, 70, 100, float('inf')]
        labels = ['Very Low', 'Low', 'Medium', 'High', 'Very High']
        
        df['mileage_category'] = pd.cut(
            df['mileage'],
            bins=bins,
            labels=labels,
            right=False
        )
        
        # Fill NaN with mode
        mode_category = df['mileage_category'].mode()[0] if not df['mileage_category'].mode().empty else 'Medium'
        df['mileage_category'].fillna(mode_category, inplace=True)
        
        return df
    
    def create_power_category(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create power categories
        
        Args:
            df: DataFrame containing 'power' column
            
        Returns:
            DataFrame with 'power_category' column
        """
        print("Creating power categories...")
        
        if 'power' not in df.columns:
            return df
        
        # Define power categories
        bins = [0, 10, 20, 30, 50, 100, float('inf')]
        labels = ['Very Low', 'Low', 'Medium', 'High', 'Very High', 'Super']
        
        df['power_category'] = pd.cut(
            df['power'],
            bins=bins,
            labels=labels,
            right=False
        )
        
        # Fill NaN with mode
        mode_category = df['power_category'].mode()[0] if not df['power_category'].mode().empty else 'Medium'
        df['power_category'].fillna(mode_category, inplace=True)
        
        return df
    
    def create_owner_encoding(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Encode owner type to numerical values
        
        Args:
            df: DataFrame containing 'owner' column
            
        Returns:
            DataFrame with 'owner_encoded' column
        """
        print("Encoding owner types...")
        
        if 'owner' not in df.columns:
            return df
        
        # Owner type mapping
        owner_mapping = {
            'first owner': 1,
            'second owner': 2,
            'third owner': 3,
            'fourth owner': 4,
            'fourth owner or above': 4,
            '3rd owner': 3,
            '2nd owner': 2,
            '1st owner': 1
        }
        
        # Clean owner strings
        df['owner_clean'] = df['owner'].astype(str).str.lower().str.strip()
        
        # Map to numerical values
        df['owner_encoded'] = df['owner_clean'].map(owner_mapping)
        
        # Fill missing values with 1 (first owner)
        df['owner_encoded'].fillna(1, inplace=True)
        
        # Drop temporary column
        df.drop('owner_clean', axis=1, inplace=True)
        
        return df
    
    def create_location_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create location-based features
        
        Args:
            df: DataFrame containing 'location' column
            
        Returns:
            DataFrame with location features
        """
        print("Creating location features...")
        
        if 'location' not in df.columns:
            return df
        
        # Clean location names
        df['location_clean'] = df['location'].astype(str).str.lower().str.strip()
        
        # Create metro city indicator
        metro_cities = [
            'delhi', 'mumbai', 'bangalore', 'chennai', 'kolkata',
            'hyderabad', 'ahmedabad', 'pune', 'surat'
        ]
        
        df['is_metro'] = df['location_clean'].apply(
            lambda x: 1 if any(city in str(x) for city in metro_cities) else 0
        )
        
        # Create region indicator (simplified)
        def get_region(location):
            location_str = str(location).lower()
            if any(city in location_str for city in ['delhi', 'chandigarh', 'punjab']):
                return 'North'
            elif any(city in location_str for city in ['mumbai', 'pune', 'ahmedabad']):
                return 'West'
            elif any(city in location_str for city in ['bangalore', 'chennai', 'hyderabad']):
                return 'South'
            elif any(city in location_str for city in ['kolkata', 'bhubaneswar']):
                return 'East'
            else:
                return 'Other'
        
        df['region'] = df['location_clean'].apply(get_region)
        
        return df
    
    def create_time_based_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create time-based features
        
        Args:
            df: DataFrame containing 'model_year' column
            
        Returns:
            DataFrame with time-based features
        """
        print("Creating time-based features...")
        
        if 'model_year' not in df.columns:
            return df
        
        # Create year categories
        df['year_category'] = pd.cut(
            df['model_year'],
            bins=[1990, 2000, 2010, 2015, 2020, 2025],
            labels=['Pre-2000', '2000-2010', '2010-2015', '2015-2020', '2020+']
        )
        
        # Create decade feature
        df['decade'] = (df['model_year'] // 10) * 10
        
        # Create is_new feature (bikes less than 2 years old)
        df['is_new'] = (self.current_year - df['model_year'] <= 2).astype(int)
        
        return df
    
    def create_interaction_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create interaction features between existing features
        
        Args:
            df: DataFrame with basic features
            
        Returns:
            DataFrame with interaction features
        """
        print("Creating interaction features...")
        
        # Power per year (power retention)
        if 'power' in df.columns and 'bike_age' in df.columns:
            df['power_per_year'] = df['power'] / (df['bike_age'] + 1)
        
        # Mileage per cc (efficiency ratio)
        if 'mileage' in df.columns and 'cc' in df.columns:
            df['mileage_per_cc'] = df['mileage'] / (df['cc'] + 1)
        
        # Price per cc (value ratio)
        if 'price' in df.columns and 'cc' in df.columns:
            df['price_per_cc'] = df['price'] / (df['cc'] + 1)
        
        # Price per power (value per horsepower)
        if 'price' in df.columns and 'power' in df.columns:
            df['price_per_power'] = df['price'] / (df['power'] + 1)
        
        return df
    
    def engineer_all_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply all feature engineering steps
        
        Args:
            df: Raw DataFrame
            
        Returns:
            DataFrame with all engineered features
        """
        print("\n" + "="*50)
        print("STARTING FEATURE ENGINEERING")
        print("="*50)
        
        # Create a copy to avoid modifying original
        df_eng = df.copy()
        
        # Step 1: Extract basic features from model name
        if 'model_name' in df_eng.columns:
            df_eng['cc'] = self.extract_cc_from_model(df_eng['model_name'])
            df_eng['brand'] = self.extract_brand_from_model(df_eng['model_name'])
            df_eng = self.clean_brand_names(df_eng)
        
        # Step 2: Create derived features
        df_eng = self.create_bike_age(df_eng)
        df_eng = self.create_power_to_cc_ratio(df_eng)
        
        # Step 3: Create categorical features
        df_eng = self.create_mileage_category(df_eng)
        df_eng = self.create_power_category(df_eng)
        
        # Step 4: Encode categorical variables
        df_eng = self.create_owner_encoding(df_eng)
        df_eng = self.create_location_features(df_eng)
        
        # Step 5: Create time-based features
        df_eng = self.create_time_based_features(df_eng)
        
        # Step 6: Create interaction features
        df_eng = self.create_interaction_features(df_eng)
        
        print("\n" + "="*50)
        print("FEATURE ENGINEERING COMPLETED")
        print(f"Original features: {len(df.columns)}")
        print(f"Engineered features: {len(df_eng.columns)}")
        print("="*50)
        
        return df_eng
    
    def get_feature_summary(self, df: pd.DataFrame) -> Dict:
        """
        Get summary of engineered features
        
        Args:
            df: Engineered DataFrame
            
        Returns:
            Dictionary with feature summary
        """
        summary = {
            'total_features': len(df.columns),
            'numeric_features': list(df.select_dtypes(include=[np.number]).columns),
            'categorical_features': list(df.select_dtypes(include=['object', 'category']).columns),
            'new_features_created': [],
            'feature_dtypes': df.dtypes.to_dict()
        }
        
        # Identify engineered features (non-original)
        original_cols = ['model_name', 'model_year', 'kms_driven', 'owner', 
                        'location', 'mileage', 'power', 'price']
        
        engineered_features = [col for col in df.columns if col not in original_cols]
        summary['new_features_created'] = engineered_features
        
        return summary